package lu.uni.serval.iac_startactivity1_sink;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
  
  public BuildConfig() {}
}
