package lu.uni.serval.iac_startactivity1_sink;

import android.app.Activity;
import android.os.Bundle;

public class LaunchingActivity
  extends Activity
{
  public LaunchingActivity() {}
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
  }
}
