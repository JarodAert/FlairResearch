package lu.uni.serval.iac_startactivity1_source;

public final class BuildConfig
{
  public static final boolean DEBUG;
  
  public BuildConfig() {}
}
