package android.support.constraint.solver.widgets;

public class ConnectionCandidate
{
  public ConstraintAnchor anchorOrigin;
  public ConstraintAnchor anchorTarget;
  public float distance;
  
  public ConnectionCandidate() {}
}
