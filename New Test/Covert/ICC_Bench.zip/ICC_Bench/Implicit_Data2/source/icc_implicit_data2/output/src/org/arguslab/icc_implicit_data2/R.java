package org.arguslab.icc_implicit_data2;

public final class R
{
  public R() {}
  
  public static final class attr
  {
    public static final int layout_constraintBaseline_creator = 2130771968;
    public static final int layout_constraintBaseline_toBaselineOf = 2130771969;
    public static final int layout_constraintBottom_creator = 2130771970;
    public static final int layout_constraintBottom_toBottomOf = 2130771971;
    public static final int layout_constraintBottom_toTopOf = 2130771972;
    public static final int layout_constraintDimensionRatio = 2130771973;
    public static final int layout_constraintEnd_toEndOf = 2130771974;
    public static final int layout_constraintEnd_toStartOf = 2130771975;
    public static final int layout_constraintGuide_begin = 2130771976;
    public static final int layout_constraintGuide_end = 2130771977;
    public static final int layout_constraintGuide_percent = 2130771978;
    public static final int layout_constraintHorizontal_bias = 2130771979;
    public static final int layout_constraintHorizontal_chainStyle = 2130771980;
    public static final int layout_constraintHorizontal_weight = 2130771981;
    public static final int layout_constraintLeft_creator = 2130771982;
    public static final int layout_constraintLeft_toLeftOf = 2130771983;
    public static final int layout_constraintLeft_toRightOf = 2130771984;
    public static final int layout_constraintRight_creator = 2130771985;
    public static final int layout_constraintRight_toLeftOf = 2130771986;
    public static final int layout_constraintRight_toRightOf = 2130771987;
    public static final int layout_constraintStart_toEndOf = 2130771988;
    public static final int layout_constraintStart_toStartOf = 2130771989;
    public static final int layout_constraintTop_creator = 2130771990;
    public static final int layout_constraintTop_toBottomOf = 2130771991;
    public static final int layout_constraintTop_toTopOf = 2130771992;
    public static final int layout_constraintVertical_bias = 2130771993;
    public static final int layout_constraintVertical_chainStyle = 2130771994;
    public static final int layout_constraintVertical_weight = 2130771995;
    public static final int layout_editor_absoluteX = 2130771996;
    public static final int layout_editor_absoluteY = 2130771997;
    public static final int layout_goneMarginBottom = 2130771998;
    public static final int layout_goneMarginEnd = 2130771999;
    public static final int layout_goneMarginLeft = 2130772000;
    public static final int layout_goneMarginRight = 2130772001;
    public static final int layout_goneMarginStart = 2130772002;
    public static final int layout_goneMarginTop = 2130772003;
    public static final int layout_optimizationLevel = 2130772004;
    
    public attr() {}
  }
  
  public static final class color
  {
    public static final int colorAccent = 2130968576;
    public static final int colorPrimary = 2130968577;
    public static final int colorPrimaryDark = 2130968578;
    
    public color() {}
  }
  
  public static final class id
  {
    public static final int all = 2131165188;
    public static final int basic = 2131165189;
    public static final int chains = 2131165190;
    public static final int none = 2131165191;
    public static final int packed = 2131165185;
    public static final int parent = 2131165184;
    public static final int spread = 2131165186;
    public static final int spread_inside = 2131165187;
    
    public id() {}
  }
  
  public static final class layout
  {
    public static final int activity_foo = 2130903040;
    public static final int activity_hook = 2130903041;
    public static final int activity_main = 2130903042;
    
    public layout() {}
  }
  
  public static final class mipmap
  {
    public static final int ic_launcher = 2130837504;
    public static final int ic_launcher_round = 2130837505;
    
    public mipmap() {}
  }
  
  public static final class string
  {
    public static final int app_name = 2131034112;
    public static final int title_activity_foo = 2131034113;
    public static final int title_activity_hook = 2131034114;
    
    public string() {}
  }
  
  public static final class style
  {
    public static final int AppTheme = 2131099648;
    
    public style() {}
  }
  
  public static final class styleable
  {
    public static final int[] ConstraintLayout_Layout = { 16842948, 16843039, 16843040, 16843071, 16843072, 2130771968, 2130771969, 2130771970, 2130771971, 2130771972, 2130771973, 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982, 2130771983, 2130771984, 2130771985, 2130771986, 2130771987, 2130771988, 2130771989, 2130771990, 2130771991, 2130771992, 2130771993, 2130771994, 2130771995, 2130771996, 2130771997, 2130771998, 2130771999, 2130772000, 2130772001, 2130772002, 2130772003, 2130772004 };
    public static final int ConstraintLayout_Layout_android_maxHeight = 2;
    public static final int ConstraintLayout_Layout_android_maxWidth = 1;
    public static final int ConstraintLayout_Layout_android_minHeight = 4;
    public static final int ConstraintLayout_Layout_android_minWidth = 3;
    public static final int ConstraintLayout_Layout_android_orientation = 0;
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_creator = 5;
    public static final int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 6;
    public static final int ConstraintLayout_Layout_layout_constraintBottom_creator = 7;
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 8;
    public static final int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 9;
    public static final int ConstraintLayout_Layout_layout_constraintDimensionRatio = 10;
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 11;
    public static final int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 12;
    public static final int ConstraintLayout_Layout_layout_constraintGuide_begin = 13;
    public static final int ConstraintLayout_Layout_layout_constraintGuide_end = 14;
    public static final int ConstraintLayout_Layout_layout_constraintGuide_percent = 15;
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 16;
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 17;
    public static final int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 18;
    public static final int ConstraintLayout_Layout_layout_constraintLeft_creator = 19;
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 20;
    public static final int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 21;
    public static final int ConstraintLayout_Layout_layout_constraintRight_creator = 22;
    public static final int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 23;
    public static final int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 24;
    public static final int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 25;
    public static final int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 26;
    public static final int ConstraintLayout_Layout_layout_constraintTop_creator = 27;
    public static final int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 28;
    public static final int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 29;
    public static final int ConstraintLayout_Layout_layout_constraintVertical_bias = 30;
    public static final int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 31;
    public static final int ConstraintLayout_Layout_layout_constraintVertical_weight = 32;
    public static final int ConstraintLayout_Layout_layout_editor_absoluteX = 33;
    public static final int ConstraintLayout_Layout_layout_editor_absoluteY = 34;
    public static final int ConstraintLayout_Layout_layout_goneMarginBottom = 35;
    public static final int ConstraintLayout_Layout_layout_goneMarginEnd = 36;
    public static final int ConstraintLayout_Layout_layout_goneMarginLeft = 37;
    public static final int ConstraintLayout_Layout_layout_goneMarginRight = 38;
    public static final int ConstraintLayout_Layout_layout_goneMarginStart = 39;
    public static final int ConstraintLayout_Layout_layout_goneMarginTop = 40;
    public static final int ConstraintLayout_Layout_layout_optimizationLevel = 41;
    public static final int[] ConstraintSet = { 16842948, 16842960, 16842972, 16842996, 16842997, 16842999, 16843000, 16843001, 16843002, 16843701, 16843702, 2130771968, 2130771969, 2130771970, 2130771971, 2130771972, 2130771973, 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979, 2130771980, 2130771981, 2130771982, 2130771983, 2130771984, 2130771985, 2130771986, 2130771987, 2130771988, 2130771989, 2130771990, 2130771991, 2130771992, 2130771993, 2130771994, 2130771995, 2130771996, 2130771997, 2130771998, 2130771999, 2130772000, 2130772001, 2130772002, 2130772003 };
    public static final int ConstraintSet_android_id = 1;
    public static final int ConstraintSet_android_layout_height = 4;
    public static final int ConstraintSet_android_layout_marginBottom = 8;
    public static final int ConstraintSet_android_layout_marginEnd = 10;
    public static final int ConstraintSet_android_layout_marginLeft = 5;
    public static final int ConstraintSet_android_layout_marginRight = 7;
    public static final int ConstraintSet_android_layout_marginStart = 9;
    public static final int ConstraintSet_android_layout_marginTop = 6;
    public static final int ConstraintSet_android_layout_width = 3;
    public static final int ConstraintSet_android_orientation = 0;
    public static final int ConstraintSet_android_visibility = 2;
    public static final int ConstraintSet_layout_constraintBaseline_creator = 11;
    public static final int ConstraintSet_layout_constraintBaseline_toBaselineOf = 12;
    public static final int ConstraintSet_layout_constraintBottom_creator = 13;
    public static final int ConstraintSet_layout_constraintBottom_toBottomOf = 14;
    public static final int ConstraintSet_layout_constraintBottom_toTopOf = 15;
    public static final int ConstraintSet_layout_constraintDimensionRatio = 16;
    public static final int ConstraintSet_layout_constraintEnd_toEndOf = 17;
    public static final int ConstraintSet_layout_constraintEnd_toStartOf = 18;
    public static final int ConstraintSet_layout_constraintGuide_begin = 19;
    public static final int ConstraintSet_layout_constraintGuide_end = 20;
    public static final int ConstraintSet_layout_constraintGuide_percent = 21;
    public static final int ConstraintSet_layout_constraintHorizontal_bias = 22;
    public static final int ConstraintSet_layout_constraintHorizontal_chainStyle = 23;
    public static final int ConstraintSet_layout_constraintHorizontal_weight = 24;
    public static final int ConstraintSet_layout_constraintLeft_creator = 25;
    public static final int ConstraintSet_layout_constraintLeft_toLeftOf = 26;
    public static final int ConstraintSet_layout_constraintLeft_toRightOf = 27;
    public static final int ConstraintSet_layout_constraintRight_creator = 28;
    public static final int ConstraintSet_layout_constraintRight_toLeftOf = 29;
    public static final int ConstraintSet_layout_constraintRight_toRightOf = 30;
    public static final int ConstraintSet_layout_constraintStart_toEndOf = 31;
    public static final int ConstraintSet_layout_constraintStart_toStartOf = 32;
    public static final int ConstraintSet_layout_constraintTop_creator = 33;
    public static final int ConstraintSet_layout_constraintTop_toBottomOf = 34;
    public static final int ConstraintSet_layout_constraintTop_toTopOf = 35;
    public static final int ConstraintSet_layout_constraintVertical_bias = 36;
    public static final int ConstraintSet_layout_constraintVertical_chainStyle = 37;
    public static final int ConstraintSet_layout_constraintVertical_weight = 38;
    public static final int ConstraintSet_layout_editor_absoluteX = 39;
    public static final int ConstraintSet_layout_editor_absoluteY = 40;
    public static final int ConstraintSet_layout_goneMarginBottom = 41;
    public static final int ConstraintSet_layout_goneMarginEnd = 42;
    public static final int ConstraintSet_layout_goneMarginLeft = 43;
    public static final int ConstraintSet_layout_goneMarginRight = 44;
    public static final int ConstraintSet_layout_goneMarginStart = 45;
    public static final int ConstraintSet_layout_goneMarginTop = 46;
    public static final int[] LinearConstraintLayout = { 16842948 };
    public static final int LinearConstraintLayout_android_orientation;
    
    public styleable() {}
  }
}
