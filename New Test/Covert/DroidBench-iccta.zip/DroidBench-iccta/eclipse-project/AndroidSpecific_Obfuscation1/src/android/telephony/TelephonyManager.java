package android.telephony;

public class TelephonyManager {
	
	public String getDeviceId() {
		return "fake";
	}

}
