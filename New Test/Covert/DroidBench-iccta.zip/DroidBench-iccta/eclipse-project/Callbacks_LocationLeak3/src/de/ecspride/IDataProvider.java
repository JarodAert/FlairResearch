package de.ecspride;

public interface IDataProvider {
	
	public void setData(String data);

}
