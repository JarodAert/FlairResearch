package de.ecspride;

public class VarB extends General{
	@Override
	public String getInfo() {
		return "abc";
	}
}
