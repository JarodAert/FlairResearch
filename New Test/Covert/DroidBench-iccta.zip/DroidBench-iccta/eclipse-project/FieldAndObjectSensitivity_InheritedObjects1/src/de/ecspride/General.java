package de.ecspride;

import android.telephony.TelephonyManager;

public abstract class General {
	TelephonyManager man;
	public abstract String getInfo();
}
